﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace FindPathRobot
{
    public partial class Form1 : Form
    {
        private const int TOTAL_SECONDS = 61;
        private const int NONE = 0;
        private const int DOWN = 1;
        private const int LEFT = 2;
        private const int RIGHT = 3;
        private const int UP = 4;
        private Random random = new Random();
        private int total_seconds;
        private int row, col;
        private int startRow, startCol;
        private bool isStarterCellClicked;
        private int robotScores = 0, countRecursive = 0, robotBestScore = 0;

        private Cell[,] cellsPlayer, cellsRobot;
        private List<Cell> possiblePath = new List<Cell>();
        private List<Cell> bestPath = new List<Cell>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnStart.Enabled = false;
            btnStopTime.Enabled = false;
            radioBtnPlayer.Checked = true;
            groupBoxMode.Enabled = false;
            btnNewGame.Enabled = true;
            panelRobot.Enabled = false;
        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            createNewGame();
        }

        private void createNewGame()
        {
            btnStart.Enabled = true;
            radioBtnPlayer.Checked = true;
            stopTimer();
            total_seconds = TOTAL_SECONDS;
            isStarterCellClicked = false;
            robotScores = robotBestScore = 0;
            possiblePath.Clear();
            bestPath.Clear();
            playerScore.Text = 0 + "";
            robotScore.Text = 0 + "";
            createCells();
            displayCellsOnPanel();
        }

        private void stopTimer()
        {
            btnStopTime.Enabled = false;
            timer1.Enabled = false;
            labelTime.Text = "0s";
        }

        private void createCells()
        {
            row = random.Next(3, 10);
            col = random.Next(3, 10);
            cellsPlayer = new Cell[row, col];
            cellsRobot = new Cell[row, col];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    cellsPlayer[i, j] = new Cell();
                    cellsRobot[i, j] = new Cell();
                    configCells(ref cellsPlayer[i, j], i, j);
                    configCells(ref cellsRobot[i, j], i, j);

                    int randomBlock, randomValue;
                    randomBlock = random.Next(0, 2);
                    randomValue = random.Next(1, 100);
                    addValueToCells(ref cellsPlayer[i, j], ref randomBlock, ref randomValue);
                    addValueToCells(ref cellsRobot[i, j], ref randomBlock, ref randomValue);
                }
            }
        }

        private void configCells(ref Cell cell, int i, int j)
        {
            cell.Font = new Font(SystemFonts.DefaultFont.FontFamily, 14);
            cell.Size = new Size(44, 44);
            cell.ForeColor = SystemColors.ControlDarkDark;
            cell.Location = new Point(j * 44, i * 44); // Point(x,y) x truc hoanh = col, y truc tung = row
            cell.FlatStyle = FlatStyle.Flat;
            cell.FlatAppearance.BorderColor = Color.Black;
            cell.CellRow = i;
            cell.CellCol = j;
        }

        private void addValueToCells(ref Cell cell, ref int randomBlock, ref int randomValue)
        {
            if (randomBlock == 1)
            {
                cell.Value = randomValue;
                cell.IsLocked = false;
                cell.BackColor = SystemColors.Control;
                cell.Text = randomValue.ToString();
                // Assign key press event for each not locked cellsPlayer
                cell.Click += cell_mouseClick;
            }
            else
            {
                cell.Value = 0;
                cell.Text = 0 + "";
                cell.IsLocked = true;
                cell.BackColor = Color.LightGray;
            }
        }

        private void displayCellsOnPanel()
        {
            panelPlayer.Controls.Clear();
            panelRobot.Controls.Clear();
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    panelPlayer.Controls.Add(cellsPlayer[i, j]);
                    panelRobot.Controls.Add(cellsRobot[i, j]);
                }
            }
        }

        private void cell_mouseClick(object sender, EventArgs e)
        {
            var cell = sender as Cell;
            if (!btnStart.Enabled && !cell.IsLocked)
            {
                setStarterCell(ref cell);
                addScores(ref cell);
                setClickedCell(ref cell);
                int cellRow = cell.CellRow;
                int cellCol = cell.CellCol;
                if (isMoveable(ref cellsPlayer, ref cellRow, ref cellCol) == NONE)
                {
                    stopTimer();
                    radioBtnRobot.Checked = true;
                    robotFindPath(startRow, startCol);
                    showResult();
                }
            }
        }

        private void setStarterCell(ref Cell cell)
        {
            if (!isStarterCellClicked)
            {
                startRow = cell.CellRow;
                startCol = cell.CellCol;
                isStarterCellClicked = true;
            }
        }

        private int isMoveable(ref Cell[,] cells, ref int i, ref int j)
        {
            // Down
            if (i + 1 < row && !cells[i + 1, j].IsLocked)
            {
                return DOWN;
            }
            // Left
            if (j - 1 >= 0 && !cells[i, j - 1].IsLocked)
            {
                return LEFT;
            }
            // Right
            if (j + 1 < col && !cells[i, j + 1].IsLocked)
            {
                return RIGHT;
            }
            // Up
            if (i - 1 >= 0 && !cells[i - 1, j].IsLocked)
            {
                return UP;
            }
            return NONE;
        }

        private void addScores(ref Cell cell)
        {
            if (!cell.IsLocked)
            {
                int currentScores = int.Parse(playerScore.Text.ToString()) + cell.Value;
                playerScore.Text = currentScores + "";
            }
        }

        private void setClickedCell(ref Cell cell)
        {
            cell.IsLocked = true;
            cell.BackColor = Color.BlueViolet;
            cell.ForeColor = Color.White;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = false;
            btnStopTime.Enabled = true;
            timer1.Enabled = true;
        }

        private void btnStopTime_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = true;
            stopTimer();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (total_seconds > 0)
            {
                total_seconds--;
                labelTime.Text = total_seconds.ToString() + "s";
            }
            else
            {
                timer1.Stop();
                btnStopTime.Enabled = false;
                btnNewGame.Enabled = true;
                robotFindPath(startRow, startCol);
                showResult();
            }
        }

        private void showResult()
        {
            int playerBestScores = int.Parse(playerScore.Text.ToString());
            if (playerBestScores < robotBestScore)
                MessageBox.Show("You Lost!", "Result");
            else if (playerBestScores == robotBestScore)
                MessageBox.Show("Draw!", "Result");
            else
                MessageBox.Show("You Won!", "Result");

        }

        private void robotFindPath(int startRow, int startCol)
        {
            if (cellsRobot[startRow, startCol].IsLocked)
            {
                return;
            }
            else
            {
                if (isMoveable(ref cellsRobot, ref startRow, ref startCol) != NONE)
                {
                    robotScores += cellsRobot[startRow, startCol].Value;
                    cellsRobot[startRow, startCol].IsLocked = true;
                    possiblePath.Add(cellsRobot[startRow, startCol]);
                    // Down
                    if (isMoveable(ref cellsRobot, ref startRow, ref startCol) == DOWN)
                    {
                        countRecursive++;
                        robotFindPath(startRow + 1, startCol);
                    }
                    // Left
                    if (isMoveable(ref cellsRobot, ref startRow, ref startCol) == LEFT)
                    {
                        countRecursive++;
                        robotFindPath(startRow, startCol - 1);
                    }
                    // Right
                    if (isMoveable(ref cellsRobot, ref startRow, ref startCol) == RIGHT)
                    {
                        countRecursive++;
                        robotFindPath(startRow, startCol + 1);
                    }
                    // Up
                    if (isMoveable(ref cellsRobot, ref startRow, ref startCol) == UP)
                    {
                        countRecursive++;
                        robotFindPath(startRow - 1, startCol);
                    }
                    if (countRecursive != 0)
                    {
                        countRecursive--;
                        robotScores -= cellsRobot[startRow, startCol].Value;
                        if (possiblePath.Count > 0)
                            possiblePath.RemoveAt(possiblePath.Count - 1);
                        return;
                    }
                    else
                    {
                        foreach (var item in bestPath)
                        {
                            var cell = item as Cell;
                            setClickedCell(ref cell);
                        }
                        robotScore.Text = robotBestScore + "";
                        return;
                    }
                }
                else
                {
                    robotScores += cellsRobot[startRow, startCol].Value;
                    cellsRobot[startRow, startCol].IsLocked = true;
                    possiblePath.Add(cellsRobot[startRow, startCol]);

                    if (robotScores > robotBestScore)
                    {
                        robotBestScore = robotScores;
                        bestPath.Clear();
                        foreach (var item in possiblePath)
                        {
                            bestPath.Add(cellsRobot[item.CellRow, item.CellCol]);
                        }
                    }
                    if (countRecursive != 0)
                    {
                        countRecursive--;
                        robotScores -= cellsRobot[startRow, startCol].Value;
                        if (possiblePath.Count > 0)
                            possiblePath.RemoveAt(possiblePath.Count - 1);
                        return;
                    }
                    else
                    {
                        foreach (var item in bestPath)
                        {
                            var cell = item as Cell;
                            setClickedCell(ref cell);
                        }
                        robotScore.Text = robotBestScore + "";
                        return;
                    }
                }
            }
        }
    }
}